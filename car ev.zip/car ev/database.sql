-- ============================================================
--  CAR RENTAL SYSTEM — Database Schema
--  Compatible with MySQL 5.7+ / XAMPP
-- ============================================================

CREATE DATABASE IF NOT EXISTS car_rental_db;
USE car_rental_db;

-- ─────────────────────────────────────────
-- 1. CUSTOMERS
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS customers (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    phone         VARCHAR(20)  NOT NULL,
    password      VARCHAR(255) NOT NULL,
    license_no    VARCHAR(50)  NOT NULL,
    address       TEXT,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────
-- 2. CARS
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cars (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    brand           VARCHAR(50)  NOT NULL,
    model           VARCHAR(50)  NOT NULL,
    year            YEAR         NOT NULL,
    reg_number      VARCHAR(20)  NOT NULL UNIQUE,
    category        ENUM('Sedan','SUV','Hatchback','Luxury','EV') NOT NULL,
    fuel_type       ENUM('Petrol','Diesel','Electric','Hybrid') NOT NULL DEFAULT 'Petrol',
    transmission    ENUM('Manual','Automatic') NOT NULL DEFAULT 'Automatic',
    seats           TINYINT      NOT NULL DEFAULT 5,
    price_per_day   DECIMAL(8,2) NOT NULL,
    status          ENUM('Available','Rented','Maintenance') NOT NULL DEFAULT 'Available',
    image_url       VARCHAR(255),
    -- EV-specific fields
    is_ev           TINYINT(1)   NOT NULL DEFAULT 0,
    battery_range   INT          DEFAULT NULL COMMENT 'Range in km on full charge',
    charge_time     VARCHAR(30)  DEFAULT NULL COMMENT 'e.g. 30 min (fast) / 8 hr (slow)',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────
-- 3. EV CHARGING STATIONS
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS charging_stations (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(150) NOT NULL,
    address     TEXT         NOT NULL,
    city        VARCHAR(80)  NOT NULL,
    state       VARCHAR(80)  NOT NULL,
    latitude    DECIMAL(10,7) NOT NULL,
    longitude   DECIMAL(10,7) NOT NULL,
    connector   VARCHAR(50)  DEFAULT 'CCS / CHAdeMO',
    power_kw    INT          DEFAULT 50,
    available   TINYINT(1)   DEFAULT 1,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────
-- 4. BOOKINGS
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bookings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT          NOT NULL,
    car_id          INT          NOT NULL,
    pickup_date     DATE         NOT NULL,
    return_date     DATE         NOT NULL,
    pickup_location VARCHAR(200) NOT NULL,
    drop_location   VARCHAR(200) NOT NULL,
    total_days      INT          NOT NULL,
    total_amount    DECIMAL(10,2) NOT NULL,
    status          ENUM('Pending','Confirmed','Active','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (car_id)      REFERENCES cars(id)      ON DELETE CASCADE
);

-- ─────────────────────────────────────────
-- 5. INVOICES
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoices (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    booking_id    INT          NOT NULL UNIQUE,
    invoice_no    VARCHAR(30)  NOT NULL UNIQUE,
    base_amount   DECIMAL(10,2) NOT NULL,
    tax_amount    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    discount      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    total_amount  DECIMAL(10,2) NOT NULL,
    payment_mode  ENUM('Cash','Card','UPI','Online') DEFAULT 'Cash',
    payment_status ENUM('Paid','Unpaid','Partial') DEFAULT 'Unpaid',
    issued_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);

-- ─────────────────────────────────────────
-- SEED DATA — Cars
-- ─────────────────────────────────────────
INSERT INTO cars (brand, model, year, reg_number, category, fuel_type, transmission, seats, price_per_day, status, is_ev, battery_range, charge_time) VALUES
-- Regular Cars
('Toyota',   'Camry',        2022, 'TN01AB1234', 'Sedan',    'Petrol',   'Automatic', 5, 1500.00, 'Available', 0, NULL, NULL),
('Honda',    'City',         2023, 'TN02CD5678', 'Sedan',    'Petrol',   'Automatic', 5, 1300.00, 'Available', 0, NULL, NULL),
('Mahindra', 'XUV700',       2023, 'TN03EF9012', 'SUV',      'Diesel',   'Automatic', 7, 2200.00, 'Available', 0, NULL, NULL),
('Hyundai',  'i20',          2022, 'TN04GH3456', 'Hatchback','Petrol',   'Manual',    5,  900.00, 'Available', 0, NULL, NULL),
('BMW',      '5 Series',     2023, 'TN05IJ7890', 'Luxury',   'Petrol',   'Automatic', 5, 4500.00, 'Available', 0, NULL, NULL),
('Maruti',   'Swift',        2022, 'TN06KL2345', 'Hatchback','Petrol',   'Manual',    5,  800.00, 'Available', 0, NULL, NULL),
('Toyota',   'Fortuner',     2023, 'TN07MN6789', 'SUV',      'Diesel',   'Automatic', 7, 2800.00, 'Rented',    0, NULL, NULL),
-- EV Cars
('Tata',     'Nexon EV',     2023, 'TN08OP1234', 'EV',       'Electric', 'Automatic', 5, 1800.00, 'Available', 1,  312, '60 min (DC Fast) / 8 hr (AC)'),
('Tata',     'Tiago EV',     2023, 'TN09QR5678', 'EV',       'Electric', 'Automatic', 5, 1400.00, 'Available', 1,  250, '58 min (DC Fast) / 8.6 hr (AC)'),
('MG',       'ZS EV',        2023, 'TN10ST9012', 'EV',       'Electric', 'Automatic', 5, 2000.00, 'Available', 1,  461, '60 min (DC Fast) / 8.5 hr (AC)'),
('BYD',      'Atto 3',       2023, 'TN11UV3456', 'EV',       'Electric', 'Automatic', 5, 2500.00, 'Available', 1,  521, '50 min (DC Fast) / 9 hr (AC)'),
('Hyundai',  'Kona Electric',2022, 'TN12WX7890', 'EV',       'Electric', 'Automatic', 5, 2200.00, 'Maintenance',1, 452, '57 min (DC Fast) / 10 hr (AC)'),
('Kia',      'EV6',          2023, 'TN13YZ2345', 'EV',       'Electric', 'Automatic', 5, 3500.00, 'Available', 1,  528, '18 min (DC Fast) / 7.5 hr (AC)');

-- SEED DATA — Charging Stations (Coimbatore area + major cities)
INSERT INTO charging_stations (name, address, city, state, latitude, longitude, connector, power_kw) VALUES
('Tata Power EV — Brookefields', 'Brookefields Mall, Brookefields', 'Coimbatore', 'Tamil Nadu', 11.0148, 76.9740, 'CCS2 / CHAdeMO', 50),
('EESL Charging Hub — RS Puram',  'D.B. Road, RS Puram',            'Coimbatore', 'Tamil Nadu', 11.0000, 76.9560, 'CCS2',            25),
('ChargeZone — Hopes', 'Hopes, Avinashi Road',                      'Coimbatore', 'Tamil Nadu', 11.0236, 77.0026, 'CCS2 / Type 2',   60),
('Zeon Charging — Gandhipuram',   'Gandhipuram Bus Stand Road',     'Coimbatore', 'Tamil Nadu', 11.0173, 76.9695, 'CHAdeMO / CCS2',  50),
('MG Fast Charger — Peelamedu',   'Peelamedu, Avinashi Road',       'Coimbatore', 'Tamil Nadu', 11.0312, 77.0259, 'CCS2',            50),
('Tata Power — Tidel Park',       'Tidel Park, Elnet Software City','Chennai',    'Tamil Nadu', 12.9965, 80.2425, 'CCS2 / CHAdeMO', 100),
('HPCL EV Point — Nungambakkam',  'Nungambakkam High Road',         'Chennai',    'Tamil Nadu', 13.0569, 80.2425, 'CCS2',            60),
('ChargeZone — Bengaluru Airport','KIAL Road, Devanahalli',         'Bengaluru',  'Karnataka',  13.1989, 77.7068, 'CCS2 / Type 2',  150),
('Ather Grid — Indiranagar',      '100 Feet Road, Indiranagar',     'Bengaluru',  'Karnataka',  12.9719, 77.6412, 'Ather Dot',       7);

-- Demo customer (password = "password123" hashed)
INSERT INTO customers (full_name, email, phone, password, license_no, address) VALUES
('Demo User', 'demo@carrental.com', '9876543210',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'TN1234567890123', '123, Anna Nagar, Coimbatore - 641001');