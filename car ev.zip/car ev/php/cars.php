<?php
// ============================================================
//  cars.php — Browse / Search / Filter Cars
// ============================================================
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

require_once 'db_connect.php';
$db     = getDB();
$action = $_GET['action'] ?? 'list';

switch ($action) {

    // ── LIST / SEARCH ─────────────────────────────────────
    case 'list':
        $where   = ["1=1"];
        $category = clean($db, $_GET['category'] ?? '');
        $fuel     = clean($db, $_GET['fuel']     ?? '');
        $status   = clean($db, $_GET['status']   ?? 'Available');
        $minPrice = (float)($_GET['min_price'] ?? 0);
        $maxPrice = (float)($_GET['max_price'] ?? 999999);
        $is_ev    = $_GET['is_ev'] ?? '';

        if ($category) $where[] = "category='$category'";
        if ($fuel)     $where[] = "fuel_type='$fuel'";
        if ($status)   $where[] = "status='$status'";
        if ($minPrice) $where[] = "price_per_day >= $minPrice";
        if ($maxPrice < 999999) $where[] = "price_per_day <= $maxPrice";
        if ($is_ev !== '') $where[] = "is_ev=" . (int)$is_ev;

        $sql = "SELECT * FROM cars WHERE " . implode(' AND ', $where) . " ORDER BY category, price_per_day";
        $res = $db->query($sql);

        $cars = [];
        while ($row = $res->fetch_assoc()) $cars[] = $row;
        sendJSON(['success'=>true,'cars'=>$cars,'count'=>count($cars)]);

    // ── SINGLE CAR DETAIL ────────────────────────────────
    case 'detail':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendJSON(['success'=>false,'message'=>'Car ID required.'], 400);

        $res = $db->query("SELECT * FROM cars WHERE id=$id LIMIT 1");
        if ($res->num_rows === 0) sendJSON(['success'=>false,'message'=>'Car not found.'], 404);
        sendJSON(['success'=>true,'car'=>$res->fetch_assoc()]);

    // ── CHECK AVAILABILITY ───────────────────────────────
    case 'availability':
        $id      = (int)($_GET['id']          ?? 0);
        $pickup  = clean($db, $_GET['pickup'] ?? '');
        $return  = clean($db, $_GET['return'] ?? '');

        if (!$id || !$pickup || !$return) {
            sendJSON(['success'=>false,'message'=>'Car ID, pickup and return date required.'], 400);
        }

        // Check if any confirmed/active booking overlaps
        $sql = "SELECT id FROM bookings
                WHERE car_id=$id
                  AND status IN ('Pending','Confirmed','Active')
                  AND NOT (return_date < '$pickup' OR pickup_date > '$return')
                LIMIT 1";
        $res = $db->query($sql);
        $available = ($res->num_rows === 0);
        sendJSON(['success'=>true,'available'=>$available]);

    default:
        sendJSON(['success'=>false,'message'=>'Unknown action.'], 400);
}
?>