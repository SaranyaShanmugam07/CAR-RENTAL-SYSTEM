<?php
// ============================================================
//  bookings.php — Create Booking / My Bookings / Cancel
// ============================================================
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

require_once 'db_connect.php';
$db     = getDB();
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // ── CREATE BOOKING ───────────────────────────────────
    case 'create':
        $cust_id  = (int)($_POST['customer_id'] ?? 0);
        $car_id   = (int)($_POST['car_id']      ?? 0);
        $pickup_d = clean($db, $_POST['pickup_date']     ?? '');
        $return_d = clean($db, $_POST['return_date']     ?? '');
        $pickup_l = clean($db, $_POST['pickup_location'] ?? '');
        $drop_l   = clean($db, $_POST['drop_location']   ?? '');

        if (!$cust_id || !$car_id || !$pickup_d || !$return_d || !$pickup_l || !$drop_l) {
            sendJSON(['success'=>false,'message'=>'All booking fields are required.'], 400);
        }

        // Calculate days & amount
        $d1   = new DateTime($pickup_d);
        $d2   = new DateTime($return_d);
        $days = $d2->diff($d1)->days;
        if ($days <= 0) sendJSON(['success'=>false,'message'=>'Return date must be after pickup date.'], 400);

        $carRes = $db->query("SELECT price_per_day, status FROM cars WHERE id=$car_id LIMIT 1");
        if ($carRes->num_rows === 0) sendJSON(['success'=>false,'message'=>'Car not found.'], 404);
        $car = $carRes->fetch_assoc();
        if ($car['status'] !== 'Available') sendJSON(['success'=>false,'message'=>'Car is not available.'], 409);

        $total = $days * $car['price_per_day'];

        // Check overlap
        $overlap = $db->query("SELECT id FROM bookings
            WHERE car_id=$car_id AND status IN ('Pending','Confirmed','Active')
            AND NOT (return_date < '$pickup_d' OR pickup_date > '$return_d') LIMIT 1");
        if ($overlap->num_rows > 0) sendJSON(['success'=>false,'message'=>'Car already booked for those dates.'], 409);

        // Insert booking
        $db->query("INSERT INTO bookings
            (customer_id,car_id,pickup_date,return_date,pickup_location,drop_location,total_days,total_amount,status)
            VALUES ($cust_id,$car_id,'$pickup_d','$return_d','$pickup_l','$drop_l',$days,$total,'Confirmed')");
        $booking_id = $db->insert_id;

        // Update car status
        $db->query("UPDATE cars SET status='Rented' WHERE id=$car_id");

        // Auto-generate invoice
        $invoice_no = 'INV-' . date('Ymd') . '-' . str_pad($booking_id, 4, '0', STR_PAD_LEFT);
        $tax        = round($total * 0.18, 2);   // 18% GST
        $grand      = $total + $tax;
        $db->query("INSERT INTO invoices (booking_id,invoice_no,base_amount,tax_amount,total_amount)
                    VALUES ($booking_id,'$invoice_no',$total,$tax,$grand)");

        sendJSON([
            'success'    => true,
            'message'    => 'Booking confirmed!',
            'booking_id' => $booking_id,
            'invoice_no' => $invoice_no,
            'total_days' => $days,
            'base_amount'=> $total,
            'tax'        => $tax,
            'grand_total'=> $grand
        ]);

    // ── MY BOOKINGS ──────────────────────────────────────
    case 'my_bookings':
        $cust_id = (int)($_GET['customer_id'] ?? 0);
        if (!$cust_id) sendJSON(['success'=>false,'message'=>'Customer ID required.'], 400);

        $sql = "SELECT b.*, c.brand, c.model, c.reg_number, c.category, c.fuel_type,
                       c.is_ev, i.invoice_no, i.total_amount AS invoice_total,
                       i.payment_status, i.tax_amount
                FROM bookings b
                JOIN cars c     ON b.car_id = c.id
                LEFT JOIN invoices i ON i.booking_id = b.id
                WHERE b.customer_id = $cust_id
                ORDER BY b.created_at DESC";
        $res = $db->query($sql);
        $bookings = [];
        while ($row = $res->fetch_assoc()) $bookings[] = $row;
        sendJSON(['success'=>true,'bookings'=>$bookings]);

    // ── CANCEL BOOKING ───────────────────────────────────
    case 'cancel':
        $booking_id = (int)($_POST['booking_id'] ?? 0);
        $cust_id    = (int)($_POST['customer_id']?? 0);

        $res = $db->query("SELECT car_id, status FROM bookings
                           WHERE id=$booking_id AND customer_id=$cust_id LIMIT 1");
        if ($res->num_rows === 0) sendJSON(['success'=>false,'message'=>'Booking not found.'], 404);
        $booking = $res->fetch_assoc();

        if (in_array($booking['status'], ['Completed','Cancelled'])) {
            sendJSON(['success'=>false,'message'=>'Cannot cancel a ' . $booking['status'] . ' booking.'], 409);
        }

        $db->query("UPDATE bookings SET status='Cancelled' WHERE id=$booking_id");
        $db->query("UPDATE cars    SET status='Available' WHERE id={$booking['car_id']}");
        sendJSON(['success'=>true,'message'=>'Booking cancelled successfully.']);

    // ── GET INVOICE ──────────────────────────────────────
    case 'invoice':
        $booking_id = (int)($_GET['booking_id'] ?? 0);
        if (!$booking_id) sendJSON(['success'=>false,'message'=>'Booking ID required.'], 400);

        $sql = "SELECT b.*, c.brand, c.model, c.reg_number, c.category, c.fuel_type,
                       cu.full_name, cu.email, cu.phone, cu.license_no,
                       i.invoice_no, i.base_amount, i.tax_amount, i.discount,
                       i.total_amount AS invoice_total, i.payment_mode, i.payment_status,
                       i.issued_at
                FROM bookings b
                JOIN cars      c  ON b.car_id      = c.id
                JOIN customers cu ON b.customer_id  = cu.id
                LEFT JOIN invoices i ON i.booking_id = b.id
                WHERE b.id = $booking_id LIMIT 1";
        $res = $db->query($sql);
        if ($res->num_rows === 0) sendJSON(['success'=>false,'message'=>'Booking not found.'], 404);
        sendJSON(['success'=>true,'invoice'=>$res->fetch_assoc()]);

    default:
        sendJSON(['success'=>false,'message'=>'Unknown action.'], 400);
}
?>