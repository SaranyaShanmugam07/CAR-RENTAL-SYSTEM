<?php
// ============================================================
//  auth.php — Customer Register / Login / Logout
// ============================================================
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

require_once 'db_connect.php';
$db     = getDB();
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // ── REGISTER ─────────────────────────────────────────
    case 'register':
        $name    = clean($db, $_POST['full_name']  ?? '');
        $email   = clean($db, $_POST['email']      ?? '');
        $phone   = clean($db, $_POST['phone']      ?? '');
        $pass    = $_POST['password'] ?? '';
        $license = clean($db, $_POST['license_no'] ?? '');
        $address = clean($db, $_POST['address']    ?? '');

        if (!$name || !$email || !$phone || !$pass || !$license) {
            sendJSON(['success'=>false,'message'=>'All fields are required.'], 400);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            sendJSON(['success'=>false,'message'=>'Invalid email address.'], 400);
        }

        // Check duplicate email
        $res = $db->query("SELECT id FROM customers WHERE email='$email'");
        if ($res->num_rows > 0) {
            sendJSON(['success'=>false,'message'=>'Email already registered.'], 409);
        }

        $hashed = password_hash($pass, PASSWORD_BCRYPT);
        $db->query("INSERT INTO customers (full_name,email,phone,password,license_no,address)
                    VALUES ('$name','$email','$phone','$hashed','$license','$address')");

        sendJSON(['success'=>true,'message'=>'Registration successful! Please login.']);

    // ── LOGIN ─────────────────────────────────────────────
    case 'login':
        session_start();
        $email = clean($db, $_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';

        $res = $db->query("SELECT * FROM customers WHERE email='$email' LIMIT 1");
        if ($res->num_rows === 0) {
            sendJSON(['success'=>false,'message'=>'Invalid email or password.'], 401);
        }
        $user = $res->fetch_assoc();
        if (!password_verify($pass, $user['password'])) {
            sendJSON(['success'=>false,'message'=>'Invalid email or password.'], 401);
        }

        $_SESSION['customer_id']   = $user['id'];
        $_SESSION['customer_name'] = $user['full_name'];
        unset($user['password']);
        sendJSON(['success'=>true,'message'=>'Login successful!','user'=>$user]);

    // ── LOGOUT ───────────────────────────────────────────
    case 'logout':
        session_start();
        session_destroy();
        sendJSON(['success'=>true,'message'=>'Logged out.']);

    default:
        sendJSON(['success'=>false,'message'=>'Unknown action.'], 400);
}
?>