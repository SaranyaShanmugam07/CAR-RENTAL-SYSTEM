<?php
// ============================================================
//  charging_stations.php — EV Charging Station Finder
// ============================================================
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

require_once 'db_connect.php';
$db     = getDB();
$action = $_GET['action'] ?? 'nearby';

switch ($action) {

    // ── NEARBY STATIONS (Haversine formula) ──────────────
    case 'nearby':
        $lat    = (float)($_GET['lat']    ?? 11.0168);   // default: Coimbatore
        $lng    = (float)($_GET['lng']    ?? 76.9558);
        $radius = (float)($_GET['radius'] ?? 50);        // km

        // Haversine distance in SQL
        $sql = "SELECT *,
                (6371 * ACOS(
                    COS(RADIANS($lat)) * COS(RADIANS(latitude))
                    * COS(RADIANS(longitude) - RADIANS($lng))
                    + SIN(RADIANS($lat)) * SIN(RADIANS(latitude))
                )) AS distance_km
                FROM charging_stations
                HAVING distance_km <= $radius
                ORDER BY distance_km ASC
                LIMIT 20";

        $res      = $db->query($sql);
        $stations = [];
        while ($row = $res->fetch_assoc()) {
            $row['distance_km'] = round($row['distance_km'], 2);
            $stations[]         = $row;
        }
        sendJSON(['success'=>true,'stations'=>$stations,'count'=>count($stations)]);

    // ── ALL STATIONS ─────────────────────────────────────
    case 'all':
        $res      = $db->query("SELECT * FROM charging_stations ORDER BY city, name");
        $stations = [];
        while ($row = $res->fetch_assoc()) $stations[] = $row;
        sendJSON(['success'=>true,'stations'=>$stations]);

    default:
        sendJSON(['success'=>false,'message'=>'Unknown action.'], 400);
}
?>