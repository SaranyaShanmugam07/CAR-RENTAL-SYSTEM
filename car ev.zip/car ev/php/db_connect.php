<?php
// ============================================================
//  db_connect.php — Database Configuration
//  Place this in your project root.
//  XAMPP default: host=localhost, user=root, password=""
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // Change if you set a MySQL root password
define('DB_NAME', 'driveease_db');

function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            http_response_code(500);
            die(json_encode([
                'success' => false,
                'message' => 'Database connection failed: ' . $conn->connect_error
            ]));
        }
        $conn->set_charset('utf8mb4');
    }
    return $conn;
}

// Helper: Send JSON response
function sendJSON($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Helper: Sanitize input
function clean($conn, $val) {
    return $conn->real_escape_string(trim($val));
}
?>