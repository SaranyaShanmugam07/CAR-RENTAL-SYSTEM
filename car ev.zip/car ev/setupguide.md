# 🚗 DriveEase — Car Rental System
## Complete Setup Guide for XAMPP

---

## 📁 Project File Structure

```
car_rental/                  ← Your project root (copy to htdocs)
├── index.html               ← Main website
├── database.sql             ← Run this in phpMyAdmin
├── css/
│   └── style.css
├── js/
│   └── app.js
└── php/
    ├── db_connect.php       ← DB config (edit credentials here)
    ├── auth.php             ← Login / Register / Logout
    ├── cars.php             ← Browse / Filter / Availability
    ├── bookings.php         ← Create booking / My bookings / Invoice
    └── charging_stations.php← EV charging station finder
```

---

## ✅ STEP-BY-STEP SETUP

### STEP 1 — Install XAMPP
- Download from: https://www.apachefriends.org/download.html
- Install and open XAMPP Control Panel
- Start **Apache** and **MySQL** (click Start for both)

---

### STEP 2 — Copy Project Files
- Go to your XAMPP installation folder:
  - Windows: `C:\xampp\htdocs\`
  - Mac/Linux: `/Applications/XAMPP/htdocs/` or `/opt/lampp/htdocs/`
- Create a folder named `car_rental` inside `htdocs`
- Copy ALL project files into `C:\xampp\htdocs\car_rental\`

Your folder should look like:
```
C:\xampp\htdocs\car_rental\
    index.html
    database.sql
    css\style.css
    js\app.js
    php\db_connect.php
    php\auth.php
    php\cars.php
    php\bookings.php
    php\charging_stations.php
```

---

### STEP 3 — Create the Database
1. Open browser → go to: **http://localhost/phpmyadmin**
2. Click **"New"** on the left sidebar
3. Database name: `car_rental_db` → Click **Create**
4. Select `car_rental_db` from the left panel
5. Click the **"Import"** tab at the top
6. Click **"Choose File"** → select `database.sql` from your project
7. Click **"Go"** (blue button at the bottom)
8. ✅ You should see "Import has been successfully finished"

---

### STEP 4 — Verify Database Connection
Open `php/db_connect.php` and check:

```php
define('DB_HOST', 'localhost');   // Keep as localhost
define('DB_USER', 'root');        // Default XAMPP user
define('DB_PASS', '');            // Empty by default in XAMPP
define('DB_NAME', 'car_rental_db');
```

> If you set a MySQL root password, update DB_PASS here.

---

### STEP 5 — Run the Website
Open browser → go to: **http://localhost/car_rental/**

You should see the DriveEase homepage! 🎉

---

### STEP 6 — Test the System

**Demo Login Credentials:**
- Email: `demo@carrental.com`
- Password: `password123`

**Test Flow:**
1. Click **Login** → use demo credentials
2. Go to **Browse Cars** → filter by EV Only
3. Click **Book Now** on any available car
4. Fill pickup/return dates and locations
5. Click **Confirm Booking** → Invoice is auto-generated
6. Go to **My Bookings** → view all bookings
7. Click **Invoice** → view/print invoice
8. Go to **EV Hub** → view EV fleet + charging map

---

## 🗄️ DATABASE TABLES EXPLAINED

| Table               | Purpose                                          |
|---------------------|--------------------------------------------------|
| `customers`         | Stores user accounts (login/register)            |
| `cars`              | All cars including EV-specific fields            |
| `bookings`          | Rental reservations with status tracking         |
| `invoices`          | Auto-generated GST invoices per booking          |
| `charging_stations` | EV charging station locations with coordinates   |

---

## ⚡ EV FEATURE EXPLAINED

The EV Hub feature:
1. Shows all electric vehicles with battery range and charge time
2. Uses **Haversine formula** in MySQL to calculate distance to charging stations
3. Displays stations on an interactive **OpenStreetMap** (Leaflet.js)
4. Allows location detection via browser GPS
5. Shows connector type, power output, and availability

To add more charging stations, insert rows into `charging_stations` table
with accurate latitude/longitude coordinates.

---

## 🔧 COMMON ISSUES & FIXES

| Issue | Fix |
|-------|-----|
| Blank page | Check Apache is running in XAMPP |
| DB error | Run database.sql again in phpMyAdmin |
| Login fails | Confirm DB_PASS is correct in db_connect.php |
| Map not loading | Ensure internet connection (Leaflet loads from CDN) |
| Cars not loading | Check browser console (F12) for PHP errors |
| 404 on PHP files | Make sure files are inside htdocs/car_rental/php/ |

---

## 📊 FEATURES SUMMARY

### Core (Problem Statement)
- ✅ Car availability management (Available/Rented/Maintenance)
- ✅ Customer registration and login
- ✅ Browse and filter cars by category, fuel, price
- ✅ Date-based booking with overlap prevention
- ✅ Rental management (view, cancel bookings)
- ✅ Auto-generated GST invoices (18% tax)
- ✅ Booking status tracking (Pending→Confirmed→Active→Completed)

### Extra Feature — EV Hub
- ✅ Dedicated EV vehicle category with battery specs
- ✅ Range and charge time displayed per vehicle
- ✅ Interactive map showing nearby charging stations
- ✅ GPS-based location detection
- ✅ Haversine distance calculation in MySQL
- ✅ Connector type, power output, availability per station

---

## 👤 DEMO CREDENTIALS
- **Email:** demo@carrental.com
- **Password:** password123

---

*Built with PHP + MySQL (XAMPP) + Vanilla JS + Leaflet.js*