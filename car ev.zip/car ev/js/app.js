// ============================================================
//  DriveEase — Car Rental System — app.js
//  All frontend logic: auth, cars, booking, EV, invoices
// ============================================================

const API = {
  auth:     'php/auth.php',
  cars:     'php/cars.php',
  bookings: 'php/bookings.php',
  ev:       'php/charging_stations.php'
};

// ── State ────────────────────────────────────────────────────
let currentUser = null;
let chargingMap = null;
let evCarId     = null;

// ── Init ─────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('driveease_user');
  if (saved) {
    currentUser = JSON.parse(saved);
    updateNavForUser();
  }
  showPage('home');
  setMinDates();
});

function setMinDates() {
  const today = new Date().toISOString().split('T')[0];
  const p = document.getElementById('pickupDate');
  const r = document.getElementById('returnDate');
  if (p) p.min = today;
  if (r) r.min = today;
}

// ── Page Navigation ──────────────────────────────────────────
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const page = document.getElementById('page-' + name);
  if (page) page.classList.add('active');

  if (name === 'cars') loadCars();
  if (name === 'ev')   { loadEVCars(); initMap(); }
  if (name === 'my-bookings') {
    if (!currentUser) { showModal('loginModal'); return; }
    loadMyBookings();
  }
  window.scrollTo(0, 0);
}

// ── Auth ─────────────────────────────────────────────────────
function updateNavForUser() {
  document.getElementById('navAuth').style.display = 'none';
  document.getElementById('navUser').style.display = 'flex';
  document.getElementById('userName').textContent  = '👤 ' + currentUser.full_name;
  document.getElementById('myBookingsNav').style.display = 'inline';
}

async function login() {
  const email = document.getElementById('loginEmail').value.trim();
  const pass  = document.getElementById('loginPass').value;
  if (!email || !pass) return showMsg('loginMsg', 'Please fill all fields.', 'error');

  const fd = new FormData();
  fd.append('action', 'login');
  fd.append('email', email);
  fd.append('password', pass);

  const res  = await postData(API.auth, fd);
  if (res.success) {
    currentUser = res.user;
    localStorage.setItem('driveease_user', JSON.stringify(currentUser));
    updateNavForUser();
    closeModal('loginModal');
    showPage('cars');
  } else {
    showMsg('loginMsg', res.message, 'error');
  }
}

async function register() {
  const fields = ['regName','regEmail','regPhone','regLicense','regAddress','regPass'];
  const [name, email, phone, license, address, pass] = fields.map(id => document.getElementById(id).value.trim());
  if (!name || !email || !phone || !license || !pass)
    return showMsg('registerMsg', 'Please fill all required fields.', 'error');

  const fd = new FormData();
  fd.append('action',     'register');
  fd.append('full_name',  name);
  fd.append('email',      email);
  fd.append('phone',      phone);
  fd.append('license_no', license);
  fd.append('address',    address);
  fd.append('password',   pass);

  const res = await postData(API.auth, fd);
  if (res.success) {
    showMsg('registerMsg', res.message + ' Redirecting to login...', 'success');
    setTimeout(() => switchModal('registerModal', 'loginModal'), 1800);
  } else {
    showMsg('registerMsg', res.message, 'error');
  }
}

function logout() {
  currentUser = null;
  localStorage.removeItem('driveease_user');
  document.getElementById('navAuth').style.display = 'flex';
  document.getElementById('navUser').style.display = 'none';
  document.getElementById('myBookingsNav').style.display = 'none';
  showPage('home');
}

// ── Cars ─────────────────────────────────────────────────────
async function loadCars() {
  const grid     = document.getElementById('carsGrid');
  const category = document.getElementById('filterCategory').value;
  const fuel     = document.getElementById('filterFuel').value;
  const evOnly   = document.getElementById('filterEV').checked;

  grid.innerHTML = '<div class="loading-spinner">Loading cars...</div>';

  let url = `${API.cars}?action=list&status=`;
  if (category) url += `&category=${category}`;
  if (fuel)     url += `&fuel=${fuel}`;
  if (evOnly)   url += `&is_ev=1`;

  const res = await getData(url);
  if (!res.success) { grid.innerHTML = '<div class="no-results">Failed to load cars.</div>'; return; }

  let cars = res.cars;
  const sort = document.getElementById('filterSort').value;
  if (sort === 'price_asc')  cars.sort((a,b) => a.price_per_day - b.price_per_day);
  if (sort === 'price_desc') cars.sort((a,b) => b.price_per_day - a.price_per_day);

  if (!cars.length) { grid.innerHTML = '<div class="no-results">No cars found for selected filters.</div>'; return; }

  grid.innerHTML = cars.map(car => carCardHTML(car)).join('');
}

function carCardHTML(car) {
  const emoji   = carEmoji(car.category, car.fuel_type);
  const statusC = car.status.toLowerCase().replace(' ','');
  const isEV    = parseInt(car.is_ev);

  let evStats = '';
  if (isEV && car.battery_range) {
    evStats = `<div class="ev-stats">
      <div>🔋 Range: <strong>${car.battery_range} km</strong></div>
      <div>⏱️ Charge: <strong>${car.charge_time}</strong></div>
    </div>`;
  }

  const bookBtn = car.status === 'Available'
    ? `<button class="btn-primary small" onclick="openBookModal(${car.id},'${car.brand} ${car.model}',${car.price_per_day},'${car.fuel_type}','${car.category}')">Book Now</button>`
    : `<button class="btn-outline small" disabled>Unavailable</button>`;

  return `<div class="car-card ${isEV ? 'ev-card' : ''}">
    <div class="car-card-img">
      ${emoji}
      <span class="status-badge ${statusC}">${car.status}</span>
      ${isEV ? '<span class="ev-badge">⚡ EV</span>' : ''}
    </div>
    <div class="car-card-body">
      <h3>${car.brand} ${car.model} (${car.year})</h3>
      <div style="font-size:.8rem;color:var(--sub)">Reg: ${car.reg_number}</div>
      <div class="car-meta">
        <span class="meta-tag">${car.category}</span>
        <span class="meta-tag ${isEV?'ev':''}">${car.fuel_type}</span>
        <span class="meta-tag">${car.transmission}</span>
        <span class="meta-tag">👥 ${car.seats} Seats</span>
      </div>
      ${evStats}
      <div class="car-card-footer">
        <div class="car-price">₹${parseFloat(car.price_per_day).toLocaleString()} <span>/day</span></div>
        ${bookBtn}
      </div>
    </div>
  </div>`;
}

function carEmoji(category, fuel) {
  if (fuel === 'Electric') return '<span style="font-size:5rem">⚡🚗</span>';
  const map = { Sedan:'🚗', SUV:'🚙', Hatchback:'🚘', Luxury:'🏎️', EV:'⚡' };
  return `<span style="font-size:5rem">${map[category] || '🚗'}</span>`;
}

// ── Booking ──────────────────────────────────────────────────
function openBookModal(carId, name, price, fuel, category) {
  if (!currentUser) { showModal('loginModal'); return; }

  document.getElementById('bookCarId').value    = carId;
  document.getElementById('bookCarPrice').value = price;
  document.getElementById('amountPreview').style.display = 'none';
  document.getElementById('bookMsg').style.display = 'none';

  const isEV = fuel === 'Electric';
  document.getElementById('bookCarInfo').innerHTML = `
    <div class="big-emoji">${isEV ? '⚡🚗' : '🚗'}</div>
    <div>
      <h3>${name}</h3>
      <p>${category} • ${fuel} • ₹${parseFloat(price).toLocaleString()}/day</p>
      ${isEV ? '<p style="color:var(--accent);font-size:.8rem;margin-top:.3rem">⚡ Electric Vehicle — Find charging stations in the EV Hub</p>' : ''}
    </div>`;

  setMinDates();
  showModal('bookModal');
}

function calcAmount() {
  const pickup = document.getElementById('pickupDate').value;
  const ret    = document.getElementById('returnDate').value;
  const price  = parseFloat(document.getElementById('bookCarPrice').value);
  if (!pickup || !ret || !price) return;

  const days = Math.ceil((new Date(ret) - new Date(pickup)) / 86400000);
  if (days <= 0) return;

  const base  = days * price;
  const tax   = base * 0.18;
  const total = base + tax;

  document.getElementById('baseAmt').textContent  = '₹' + base.toFixed(2);
  document.getElementById('taxAmt').textContent   = '₹' + tax.toFixed(2);
  document.getElementById('totalAmt').textContent = '₹' + total.toFixed(2);
  document.getElementById('amountPreview').style.display = 'block';
}

async function confirmBooking() {
  const carId  = document.getElementById('bookCarId').value;
  const pickup = document.getElementById('pickupDate').value;
  const ret    = document.getElementById('returnDate').value;
  const pickupL= document.getElementById('pickupLocation').value.trim();
  const dropL  = document.getElementById('dropLocation').value.trim();

  if (!pickup || !ret || !pickupL || !dropL)
    return showMsg('bookMsg', 'Please fill all fields.', 'error');
  if (new Date(ret) <= new Date(pickup))
    return showMsg('bookMsg', 'Return date must be after pickup date.', 'error');

  const fd = new FormData();
  fd.append('action',          'create');
  fd.append('customer_id',     currentUser.id);
  fd.append('car_id',          carId);
  fd.append('pickup_date',     pickup);
  fd.append('return_date',     ret);
  fd.append('pickup_location', pickupL);
  fd.append('drop_location',   dropL);

  const res = await postData(API.bookings, fd);
  if (res.success) {
    showMsg('bookMsg', '✅ ' + res.message, 'success');
    setTimeout(() => {
      closeModal('bookModal');
      loadCars();
      showInvoiceModal(res);
    }, 1200);
  } else {
    showMsg('bookMsg', res.message, 'error');
  }
}

// ── Invoice ──────────────────────────────────────────────────
function showInvoiceModal(booking) {
  document.getElementById('invoiceContent').innerHTML = `
    <div class="invoice-box">
      <div class="invoice-header">
        <div>
          <h2>⚡ DriveEase</h2>
          <p style="color:var(--sub);font-size:.85rem">Car Rental Invoice</p>
        </div>
        <div style="text-align:right">
          <div class="invoice-no">${booking.invoice_no}</div>
          <div style="font-size:.8rem;color:var(--sub)">${new Date().toLocaleDateString('en-IN')}</div>
        </div>
      </div>
      <div class="invoice-grid">
        <div class="invoice-section">
          <h4>Billed To</h4>
          <p>${currentUser.full_name}<br>${currentUser.email}<br>${currentUser.phone}</p>
        </div>
        <div class="invoice-section">
          <h4>Booking Details</h4>
          <p>Booking ID: #${booking.booking_id}<br>Days: ${booking.total_days}</p>
        </div>
      </div>
      <table class="invoice-table">
        <thead><tr><th>Description</th><th>Amount</th></tr></thead>
        <tbody>
          <tr><td>Car Rental (${booking.total_days} days)</td><td>₹${parseFloat(booking.base_amount).toFixed(2)}</td></tr>
          <tr><td>GST (18%)</td><td>₹${parseFloat(booking.tax).toFixed(2)}</td></tr>
          <tr><td class="grand">Grand Total</td><td class="grand">₹${parseFloat(booking.grand_total).toFixed(2)}</td></tr>
        </tbody>
      </table>
      <p style="color:var(--sub);font-size:.8rem;text-align:center">Thank you for choosing DriveEase! Drive safe. 🌱</p>
    </div>`;
  showModal('invoiceModal');
}

async function viewInvoice(bookingId) {
  const res = await getData(`${API.bookings}?action=invoice&booking_id=${bookingId}`);
  if (!res.success) return alert('Could not load invoice.');
  const inv = res.invoice;

  document.getElementById('invoiceContent').innerHTML = `
    <div class="invoice-box">
      <div class="invoice-header">
        <div><h2>⚡ DriveEase</h2><p style="color:var(--sub);font-size:.85rem">Car Rental Invoice</p></div>
        <div style="text-align:right">
          <div class="invoice-no">${inv.invoice_no || 'N/A'}</div>
          <div style="font-size:.8rem;color:var(--sub)">${inv.issued_at ? new Date(inv.issued_at).toLocaleDateString('en-IN') : ''}</div>
        </div>
      </div>
      <div class="invoice-grid">
        <div class="invoice-section">
          <h4>Billed To</h4>
          <p>${inv.full_name}<br>${inv.email}<br>${inv.phone}<br>License: ${inv.license_no}</p>
        </div>
        <div class="invoice-section">
          <h4>Vehicle Details</h4>
          <p>${inv.brand} ${inv.model}<br>Reg: ${inv.reg_number}<br>${inv.category} • ${inv.fuel_type}</p>
        </div>
        <div class="invoice-section">
          <h4>Rental Period</h4>
          <p>Pickup: ${inv.pickup_date}<br>Return: ${inv.return_date}<br>Days: ${inv.total_days}</p>
        </div>
        <div class="invoice-section">
          <h4>Locations</h4>
          <p>📍 ${inv.pickup_location}<br>📍 ${inv.drop_location}</p>
        </div>
      </div>
      <table class="invoice-table">
        <thead><tr><th>Description</th><th>Amount</th></tr></thead>
        <tbody>
          <tr><td>Car Rental (${inv.total_days} days × ₹${parseFloat(inv.total_amount/inv.total_days||0).toFixed(0)})</td><td>₹${parseFloat(inv.base_amount).toFixed(2)}</td></tr>
          <tr><td>GST (18%)</td><td>₹${parseFloat(inv.tax_amount).toFixed(2)}</td></tr>
          ${inv.discount>0?`<tr><td>Discount</td><td>-₹${parseFloat(inv.discount).toFixed(2)}</td></tr>`:''}
          <tr><td class="grand">Grand Total</td><td class="grand">₹${parseFloat(inv.invoice_total).toFixed(2)}</td></tr>
        </tbody>
      </table>
      <div style="display:flex;justify-content:space-between;font-size:.82rem;color:var(--sub)">
        <span>Payment: ${inv.payment_mode || 'N/A'}</span>
        <span style="color:${inv.payment_status==='Paid'?'var(--accent)':'var(--warning)'}">
          ${inv.payment_status || 'Unpaid'}
        </span>
      </div>
      <p style="color:var(--sub);font-size:.8rem;text-align:center;margin-top:1rem">Thank you for choosing DriveEase! 🌱</p>
    </div>`;
  showModal('invoiceModal');
}

function printInvoice() {
  const html = document.getElementById('invoiceContent').innerHTML;
  const w = window.open('', '_blank');
  w.document.write(`<html><head><title>Invoice</title>
    <style>
      body{font-family:sans-serif;padding:2rem;color:#111}
      table{width:100%;border-collapse:collapse}
      th,td{padding:.6rem;border:1px solid #ddd;text-align:left}
      th{background:#f5f5f5}
      .grand{font-weight:700}
    </style></head><body>${html}</body></html>`);
  w.document.close();
  w.print();
}

// ── My Bookings ───────────────────────────────────────────────
async function loadMyBookings() {
  const list = document.getElementById('bookingsList');
  list.innerHTML = '<div class="loading-spinner">Loading bookings...</div>';

  const res = await getData(`${API.bookings}?action=my_bookings&customer_id=${currentUser.id}`);
  if (!res.success) { list.innerHTML = '<div class="no-results">Failed to load bookings.</div>'; return; }
  if (!res.bookings.length) { list.innerHTML = '<div class="no-results">No bookings found. <a href="#" onclick="showPage(\'cars\')">Browse cars →</a></div>'; return; }

  list.innerHTML = res.bookings.map(b => `
    <div class="booking-card">
      <div>
        <h3>${b.brand} ${b.model} ${b.is_ev == 1 ? '⚡' : ''}</h3>
        <div class="booking-meta">
          <span>📅 ${b.pickup_date} → ${b.return_date}</span>
          <span>📍 ${b.pickup_location}</span>
          <span>🚗 Reg: ${b.reg_number}</span>
          ${b.invoice_no ? `<span>🧾 ${b.invoice_no}</span>` : ''}
        </div>
        <div style="font-size:.88rem;margin-top:.4rem">
          <strong style="color:var(--accent)">₹${parseFloat(b.invoice_total||b.total_amount).toFixed(2)}</strong>
          ${b.payment_status ? `<span style="color:var(--sub);margin-left:.5rem">${b.payment_status}</span>` : ''}
        </div>
        <div class="booking-actions" style="margin-top:.7rem">
          <button class="btn-outline small" onclick="viewInvoice(${b.id})">🧾 Invoice</button>
          ${['Pending','Confirmed'].includes(b.status)
            ? `<button class="btn-outline small" style="color:var(--danger);border-color:var(--danger)"
                onclick="cancelBooking(${b.id})">Cancel</button>`
            : ''}
        </div>
      </div>
      <div>
        <span class="booking-status ${b.status}">${b.status}</span>
      </div>
    </div>`).join('');
}

async function cancelBooking(bookingId) {
  if (!confirm('Are you sure you want to cancel this booking?')) return;
  const fd = new FormData();
  fd.append('action',      'cancel');
  fd.append('booking_id',  bookingId);
  fd.append('customer_id', currentUser.id);
  const res = await postData(API.bookings, fd);
  alert(res.message);
  if (res.success) loadMyBookings();
}

// ── EV Hub ────────────────────────────────────────────────────
async function loadEVCars() {
  const grid = document.getElementById('evCarsGrid');
  const res  = await getData(`${API.cars}?action=list&is_ev=1`);
  if (!res.success || !res.cars.length) {
    grid.innerHTML = '<div class="no-results">No EV cars found.</div>'; return;
  }
  grid.innerHTML = res.cars.map(car => `
    <div class="ev-car-row">
      <div class="ev-emoji">⚡🚗</div>
      <div>
        <h4>${car.brand} ${car.model} (${car.year})</h4>
        <div class="ev-detail">
          🔋 ${car.battery_range} km range &nbsp;|&nbsp; ⏱️ ${car.charge_time}
        </div>
        <div class="ev-detail" style="color:${car.status==='Available'?'var(--accent)':'var(--danger)'}">
          ● ${car.status}
        </div>
      </div>
      <div class="ev-price">
        <strong>₹${parseFloat(car.price_per_day).toLocaleString()}/day</strong>
        ${car.status==='Available'
          ? `<button class="btn-primary small" style="margin-top:.4rem"
              onclick="openBookModal(${car.id},'${car.brand} ${car.model}',${car.price_per_day},'Electric','EV')">Book</button>`
          : ''}
      </div>
    </div>`).join('');
}

function initMap() {
  if (chargingMap) return;
  setTimeout(() => {
    chargingMap = L.map('chargingMap').setView([11.0168, 76.9558], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(chargingMap);
    findStations();
  }, 200);
}

function useMyLocation() {
  if (!navigator.geolocation) return alert('Geolocation not supported.');
  navigator.geolocation.getCurrentPosition(pos => {
    document.getElementById('userLat').value = pos.coords.latitude.toFixed(6);
    document.getElementById('userLng').value = pos.coords.longitude.toFixed(6);
    findStations();
  }, () => alert('Could not get location. Please enter manually.'));
}

async function findStations() {
  const lat = document.getElementById('userLat').value;
  const lng = document.getElementById('userLng').value;
  if (!lat || !lng) return;

  const res = await getData(`${API.ev}?action=nearby&lat=${lat}&lng=${lng}&radius=100`);
  if (!res.success) return;

  // Update map
  if (chargingMap) {
    chargingMap.eachLayer(layer => { if (layer instanceof L.Marker) chargingMap.removeLayer(layer); });
    chargingMap.setView([parseFloat(lat), parseFloat(lng)], 11);

    // User marker
    L.marker([parseFloat(lat), parseFloat(lng)], {
      icon: L.divIcon({ className:'', html:'<div style="font-size:1.8rem">📍</div>', iconSize:[30,30] })
    }).addTo(chargingMap).bindPopup('Your Location');

    // Station markers
    res.stations.forEach(s => {
      const icon = L.divIcon({ className:'', html:'<div style="font-size:1.8rem">⚡</div>', iconSize:[30,30] });
      L.marker([parseFloat(s.latitude), parseFloat(s.longitude)], { icon })
        .addTo(chargingMap)
        .bindPopup(`<b>${s.name}</b><br>${s.address}<br>
          <b>${s.connector}</b> • ${s.power_kw} kW<br>
          ${s.distance_km} km away`);
    });
  }

  // Station list
  const list = document.getElementById('stationsList');
  if (!res.stations.length) {
    list.innerHTML = '<div class="no-results">No charging stations found within 100 km.</div>';
    return;
  }
  list.innerHTML = res.stations.map(s => `
    <div class="station-item">
      <div class="station-icon">⚡</div>
      <div class="station-info">
        <h4>${s.name}</h4>
        <p>${s.address}, ${s.city}</p>
        <p style="color:var(--accent);font-size:.75rem">${s.connector} • ${s.power_kw} kW • ${s.available?'✅ Available':'❌ Busy'}</p>
      </div>
      <div class="station-dist">
        <strong>${s.distance_km} km</strong>
        <div style="font-size:.72rem;color:var(--sub)">away</div>
      </div>
    </div>`).join('');
}

// ── Modal Helpers ─────────────────────────────────────────────
function showModal(id) {
  document.getElementById(id).classList.add('open');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}
function closeModalOutside(e, id) {
  if (e.target.id === id) closeModal(id);
}
function switchModal(from, to) {
  closeModal(from);
  showModal(to);
}
function showMsg(id, msg, type) {
  const el = document.getElementById(id);
  el.textContent = msg;
  el.className   = 'msg-box ' + type;
  el.style.display = 'block';
}

// ── API Helpers ───────────────────────────────────────────────
async function getData(url) {
  try {
    const r = await fetch(url);
    return await r.json();
  } catch (e) {
    console.error('GET error:', e);
    return { success: false, message: 'Network error.' };
  }
}
async function postData(url, formData) {
  try {
    const r = await fetch(url, { method: 'POST', body: formData });
    return await r.json();
  } catch (e) {
    console.error('POST error:', e);
    return { success: false, message: 'Network error.' };
  }
}